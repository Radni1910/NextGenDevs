import 'dart:io';
import 'package:flutter/foundation.dart';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

class AdminLostFoundScreen extends StatefulWidget {
  const AdminLostFoundScreen({super.key});

  @override
  State<AdminLostFoundScreen> createState() => _AdminLostFoundScreenState();
}

class _AdminLostFoundScreenState extends State<AdminLostFoundScreen> {
  // 🎨 Student theme colors
  static const Color primaryGreen = Color.fromARGB(255, 5, 35, 81);
  static const Color lightGreenBg = Color(0xFFEFFAF2);
  static const Color borderGreen = Color(0xFFC8E6C9);

  // 🔍 Filters
  String selectedFilter = "All";
  String searchText = "";

  // ✍️ Controllers
  final TextEditingController _descCtrl = TextEditingController();
  final TextEditingController _locationCtrl = TextEditingController();

  // 🧾 Bottom sheet state
  String selectedStatus = "lost";
  DateTime selectedDate = DateTime.now();
  File? selectedImage;
  bool isUploadingImage = false;

  final Stream<QuerySnapshot> lostFoundStream =
  FirebaseFirestore.instance
      .collection('lost_found_items')
      .orderBy('createdAt', descending: true)
      .snapshots();

  // ===========================
  // IMAGE PICK & UPLOAD
  // ===========================
  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final XFile? picked =
    await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);

    if (picked != null) {
      setState(() {
        selectedImage = File(picked.path);
      });
    }
  }

  Future<String> _uploadImage(File image) async {
    final fileName =
        "lost_found/${DateTime.now().millisecondsSinceEpoch}.jpg";

    final ref = FirebaseStorage.instance.ref().child(fileName);
    final uploadTask = await ref.putFile(image);
    return await uploadTask.ref.getDownloadURL();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: lightGreenBg,
      appBar: AppBar(
        title: const Text(
          "Lost & Found",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        foregroundColor: primaryGreen,
        elevation: 0,
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: primaryGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("Add Item"),
        onPressed: _showAddItemSheet,
      ),
      body: Column(
        children: [
          _summaryRow(),
          _searchBar(),
          _filterChips(),
          Expanded(child: _itemsList()),
        ],
      ),
    );
  }

  // ===========================
  // SUMMARY COUNTS
  // ===========================
  Widget _summaryRow() {
    return StreamBuilder<QuerySnapshot>(
      stream: lostFoundStream,
      builder: (_, snapshot) {
        if (!snapshot.hasData) return const SizedBox();

        final docs = snapshot.data!.docs;
        final lost = docs.where((e) => e['status'] == 'lost').length;
        final found = docs.where((e) => e['status'] == 'found').length;
        final claimed = docs.where((e) => e['status'] == 'claimed').length;

        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
          child: Row(
            children: [
              _countBox("Lost", lost, const Color.fromARGB(255, 10, 28, 108)),
              _countBox("Found", found, const Color.fromARGB(255, 124, 217, 127)),
              _countBox("Claimed", claimed, const Color.fromARGB(255, 7, 5, 47)),
            ],
          ),
        );
      },
    );
  }

  Widget _countBox(String label, int count, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderGreen),
        ),
        child: Column(
          children: [
            Text(
              count.toString(),
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  // ===========================
  // SEARCH BAR
  // ===========================
  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: TextField(
        onChanged: (v) => setState(() => searchText = v),
        decoration: InputDecoration(
          hintText: "Search items...",
          prefixIcon: const Icon(Icons.search),
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  // ===========================
  // FILTER CHIPS
  // ===========================
  Widget _filterChips() {
    final filters = ["All", "lost", "found", "claimed"];

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: filters.map((f) {
          final selected = selectedFilter == f;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: ChoiceChip(
              label: Text(f.toUpperCase()),
              selected: selected,
              selectedColor: primaryGreen.withOpacity(0.15),
              onSelected: (_) => setState(() => selectedFilter = f),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ===========================
  // ITEMS LIST
  // ===========================
  Widget _itemsList() {
    return StreamBuilder<QuerySnapshot>(
      stream: lostFoundStream,
      builder: (_, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final filteredDocs = snapshot.data!.docs.where((doc) {
          final d = doc.data() as Map<String, dynamic>;

          final statusOk =
              selectedFilter == "All" || d['status'] == selectedFilter;

          final searchOk = d['description']
              .toString()
              .toLowerCase()
              .contains(searchText.toLowerCase());

          return statusOk && searchOk;
        }).toList();

        if (filteredDocs.isEmpty) {
          return const Center(child: Text("No items found"));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: filteredDocs.length,
          itemBuilder: (_, i) =>
              _adminItemCard(filteredDocs[i].data() as Map<String, dynamic>),
        );
      },
    );
  }

  // ===========================
  // ITEM CARD (UNCHANGED UI)
  // ===========================
  Widget _adminItemCard(Map<String, dynamic> d) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGreen),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            d['description'] ?? '',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            d['location'] ?? '',
            style: TextStyle(
              fontSize: 13,
              color: primaryGreen.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              d['status'].toString().toUpperCase(),
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.6,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===========================
  // ADD ITEM BOTTOM SHEET
  // ===========================
  void _showAddItemSheet() {
    _descCtrl.clear();
    _locationCtrl.clear();
    selectedStatus = "lost";
    selectedDate = DateTime.now();
    selectedImage = null;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) {
        return Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            16,
            20,
            MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const Text(
                  "Post Lost / Found Item",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),

                _section("Item Status"),
                _statusBox(),

                const SizedBox(height: 16),
                _section("Item Description"),
                _sheetInput(Icons.description_outlined, "Describe the item", _descCtrl),

                const SizedBox(height: 16),
                _section("Location"),
                _sheetInput(Icons.location_on_outlined, "Location", _locationCtrl),

                const SizedBox(height: 16),
                _section("Date"),
                _datePicker(),

                const SizedBox(height: 16),
                _section("Item Image"),
                _imageBox(),

                const SizedBox(height: 28),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryGreen,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    onPressed: isUploadingImage ? null : _addItem,
                    child: isUploadingImage
                        ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                        : const Text(
                      "Add Item",
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ===========================
  // BOTTOM SHEET HELPERS
  // ===========================
  Widget _section(String text) =>
      Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(text));

  Widget _statusBox() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: lightGreenBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGreen),
      ),
      child: Row(
        children: [
          _radio("lost", "Lost"),
          _radio("found", "Found"),
        ],
      ),
    );
  }

  Widget _radio(String value, String label) {
    return Expanded(
      child: RadioListTile<String>(
        value: value,
        groupValue: selectedStatus,
        onChanged: (v) => setState(() => selectedStatus = v!),
        title: Text(label),
        dense: true,
        contentPadding: EdgeInsets.zero,
      ),
    );
  }

  Widget _sheetInput(IconData icon, String hint, TextEditingController c) {
    return Container(
      decoration: BoxDecoration(
        color: lightGreenBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGreen),
      ),
      child: TextField(
        controller: c,
        decoration: InputDecoration(
          prefixIcon: Icon(icon),
          hintText: hint,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }

  Widget _datePicker() {
    return GestureDetector(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: selectedDate,
          firstDate: DateTime(2020),
          lastDate: DateTime.now(),
        );
        if (picked != null) {
          setState(() => selectedDate = picked);
        }
      },
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: lightGreenBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderGreen),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_today),
            const SizedBox(width: 10),
            Text("${selectedDate.day}/${selectedDate.month}/${selectedDate.year}"),
            const Spacer(),
            const Icon(Icons.keyboard_arrow_down),
          ],
        ),
      ),
    );
  }

  Widget _imageBox() {
    return GestureDetector(
      onTap: _pickImage,
      child: Container(
        height: 160,
        decoration: BoxDecoration(
          color: lightGreenBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: borderGreen),
        ),
        child: selectedImage == null
            ? Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.add_photo_alternate_outlined, size: 42),
            SizedBox(height: 8),
            Text("Add an image"),
            Text(
              "Optional",
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ],
        )
            : ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Image.file(
            selectedImage!,
            fit: BoxFit.cover,
            width: double.infinity,
          ),
        ),
      ),
    );
  }

  // ===========================
  // FIRESTORE ADD
  // ===========================
  Future<void> _addItem() async {
    String uploadedImageUrl = "";

    if (selectedImage != null) {
      setState(() => isUploadingImage = true);
      uploadedImageUrl = await _uploadImage(selectedImage!);
      setState(() => isUploadingImage = false);
    }

    await FirebaseFirestore.instance.collection('lost_found_items').add({
      'description': _descCtrl.text.trim(),
      'location': _locationCtrl.text.trim(),
      'status': selectedStatus,
      'date':
      "${selectedDate.day}/${selectedDate.month}/${selectedDate.year}",
      'imageUrl': uploadedImageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });

    Navigator.pop(context);
  }
}
