import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class IssueManageScreen extends StatefulWidget {
  const IssueManageScreen({super.key});

  @override
  State<IssueManageScreen> createState() => _IssueManageScreenState();
}

class _IssueManageScreenState extends State<IssueManageScreen> {
  String selectedFilter = 'All';
  String searchQuery = '';

  // 🎨 COLORS (UNCHANGED)
  static const Color primary = Color(0xFF22577A);
  static const Color secondary = Color(0xFF38A3A5);
  static const Color success = Color(0xFF57CC99);
  static const Color background = Color(0xFFC7F9CC);

  // 🔁 STATUS FLOW
  static const List<String> statusFlow = [
    'Open',
    'Assigned',
    'In Progress',
    'Resolved',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('issues')

            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final allIssues = snapshot.data!.docs;

          final filteredIssues = allIssues.where((doc) {
            final issue = doc.data() as Map<String, dynamic>;
            final status = issue['status'] ?? '';
            final title = issue['title'] ?? '';

            final matchesFilter =
                selectedFilter == 'All' || status == selectedFilter;

            final matchesSearch =
            title.toLowerCase().contains(searchQuery.toLowerCase());

            return matchesFilter && matchesSearch;
          }).toList();

          return Column(
            children: [
              _header(),
              _summaryRow(allIssues),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _searchBar(),
                    const SizedBox(height: 12),
                    _filterChips(),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: filteredIssues.length,
                  itemBuilder: (_, i) => _issueCard(filteredIssues[i]),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // ================= HEADER =================
  Widget _header() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 48, 16, 28),
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [primary, secondary]),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 8),
          const Text(
            "Issue Management",
            style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  // ================= SUMMARY =================
  Widget _summaryRow(List<QueryDocumentSnapshot> issues) {
    int count(String s) => issues
        .where((i) => ((i.data() as Map)['status'] ?? '') == s)
        .length;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          _summaryCard("Total", issues.length, primary),
          _summaryCard("Open", count('Open'), Colors.redAccent),
          _summaryCard("Assigned", count('Assigned'), primary),
          _summaryCard("Active", count('In Progress'), secondary),
          _summaryCard("Solved", count('Resolved'), success),
        ],
      ),
    );
  }

  Widget _summaryCard(String label, int count, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 6),
            )
          ],
        ),
        child: Column(
          children: [
            Text(count.toString(),
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: color)),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }

  // ================= SEARCH =================
  Widget _searchBar() {
    return TextField(
      onChanged: (v) => setState(() => searchQuery = v),
      decoration: InputDecoration(
        hintText: "Search issues...",
        prefixIcon: const Icon(Icons.search, color: primary),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  // ================= FILTERS =================
  Widget _filterChips() {
    final filters = ['All', ...statusFlow];

    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: filters.map((f) {
          final selected = selectedFilter == f;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(f),
              selected: selected,
              selectedColor: secondary,
              labelStyle:
              TextStyle(color: selected ? Colors.white : Colors.black),
              onSelected: (_) => setState(() => selectedFilter = f),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ================= ISSUE CARD =================
  Widget _issueCard(QueryDocumentSnapshot doc) {
    final issue = doc.data() as Map<String, dynamic>;
    final bool isOverdue = issue['isOverdue'] == true;
    final status = issue['status'] ?? 'Open';
    final title = issue['title'] ?? 'No Title';
    final location = issue['hostel'] ?? 'Unknown Hostel';
    final category = issue['category'] ?? 'General';
    final priority = issue['priority'] ?? 'Low';

    final color = _statusColor(status);


    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 12,
              offset: const Offset(0, 8)),
        ],
      ),
      child: InkWell(
        onTap: () => _showDetails(doc),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (isOverdue)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Row(
                  children: const [
                    Icon(Icons.warning_amber, color: Colors.red, size: 16),
                    SizedBox(width: 6),
                    Text(
                      'Overdue',
                      style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),

            Row(
              children: [
                _statusChip(status, color),
                const Spacer(),
                _createdAt(issue['createdAt']),
              ],
            ),
            const SizedBox(height: 10),
            Text(title,
                style:
                const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(location, style: const TextStyle(color: Colors.grey)),
            const Divider(height: 24),
            Row(
              children: [
                _tag(category, primary),
                const SizedBox(width: 8),
                _tag(priority, _priorityColor(priority)),
                const Spacer(),
                const Icon(Icons.arrow_forward_ios, size: 14),
              ],
            ),
          ],
        ),
      ),
    );

  }

  // ================= BOTTOM SHEET =================
  void _showDetails(QueryDocumentSnapshot doc) {
    final issue = doc.data() as Map<String, dynamic>;
    final status = issue['status'] ?? 'Open';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(issue['title'] ?? 'No Title',
                style:
                const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            _statusChip(status, _statusColor(status)),
            const SizedBox(height: 14),
            Text(issue['description'] ?? 'No description'),
            const SizedBox(height: 24),

            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                if (status == 'Open')
                  _actionButton(
                    "Assign Issue",
                    Icons.person_add,
                    primary,
                        () => _updateStatus(doc, 'Assigned'),
                  ),
                if (status == 'Assigned')
                  _actionButton(
                    "Start Progress",
                    Icons.play_arrow,
                    secondary,
                        () => _updateStatus(doc, 'In Progress'),
                  ),
                if (status == 'In Progress')
                  _actionButton(
                    "Resolve Issue",
                    Icons.check_circle,
                    success,
                        () => _updateStatus(doc, 'Resolved'),
                  ),
                if (status == 'Resolved')
                  _actionButton(
                    "Already Resolved",
                    Icons.lock,
                    Colors.grey,
                    null,
                  ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  // ================= HELPERS =================
  Widget _actionButton(
      String label, IconData icon, Color color, VoidCallback? onTap) {
    return ElevatedButton.icon(
      style: ElevatedButton.styleFrom(
        backgroundColor: onTap == null ? Colors.grey.shade300 : color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      onPressed: onTap,
      icon: Icon(icon, size: 18),
      label: Text(label),
    );
  }

  Future<void> _updateStatus(
      QueryDocumentSnapshot doc,
      String newStatus,
      ) async {
    final issue = doc.data() as Map<String, dynamic>;
    final String currentStatus = issue['status'] ?? 'Open';

    const List<String> flow = [
      'Open',
      'Assigned',
      'In Progress',
      'Resolved',
    ];

    final int currentIndex = flow.indexOf(currentStatus);
    final int newIndex = flow.indexOf(newStatus);

    // 🚨 INVALID TRANSITION GUARD
    if (newIndex != currentIndex + 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Invalid status change: $currentStatus → $newStatus',
          ),
        ),
      );
      return;
    }

    // ✅ VALID UPDATE
    final Map<String, dynamic> updateData = {
      'status': newStatus,
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (newStatus == 'Assigned') {
      updateData['assignedAt'] = FieldValue.serverTimestamp();
    }

    if (newStatus == 'In Progress') {
      updateData['inProgressAt'] = FieldValue.serverTimestamp();
    }

    if (newStatus == 'Resolved') {
      updateData['resolvedAt'] = FieldValue.serverTimestamp();
    }

    await FirebaseFirestore.instance
        .collection('issues')
        .doc(doc.id)
        .update(updateData);

    Navigator.pop(context);
  }

  Widget _statusChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: 12)),
    );
  }

  Widget _createdAt(dynamic ts) {
    if (ts is Timestamp) {
      return Text(ts.toDate().toString().substring(0, 16),
          style: const TextStyle(color: Colors.grey));
    }
    return const SizedBox();
  }

  Widget _tag(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        border: Border.all(color: color.withOpacity(0.4)),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: 11)),
    );
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'Open':
        return Colors.redAccent;
      case 'Assigned':
        return primary;
      case 'In Progress':
        return secondary;
      case 'Resolved':
        return success;
      default:
        return primary;
    }
  }

  Color _priorityColor(String p) {
    switch (p) {
      case 'High':
        return Colors.red;
      case 'Medium':
        return Colors.orange;
      case 'Low':
        return primary;
      default:
        return Colors.grey;
    }
  }
}
