import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'issue_details_screen.dart';

class ReportIssueScreen extends StatefulWidget {
  const ReportIssueScreen({super.key});

  @override
  State<ReportIssueScreen> createState() => _ReportIssueScreenState();
}

class _ReportIssueScreenState extends State<ReportIssueScreen> {

  bool isOtherCategory = false;

  final TextEditingController otherCategoryController = TextEditingController();

  String selectedCategory = 'Plumbing';
  String selectedPriority = 'Medium';
  bool isPublic = true;
  bool isSubmitting = false;

  // ✅ Image Picker
  final ImagePicker _picker = ImagePicker();
  final List<XFile> pickedImages = [];

  // ✅ Text Controllers
  final TextEditingController descriptionController = TextEditingController();

  // ✅ Firebase instances
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // 🎨 Same Theme as Announcement Screen
  static const Color primaryGreen = Color.fromARGB(255, 5, 35, 81);
  static const Color lightGreenBg = Color(0xFFEFFAF2);
  static const Color borderGreen = Color(0xFFC8E6C9);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: lightGreenBg,

      appBar: AppBar(
        title: const Text(
          "Report New Issue",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Color.fromARGB(255, 5, 35, 81),
        elevation: 0,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "What is the problem?",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 4, 45, 79),
              ),
            ),
            const SizedBox(height: 20),

            // ✅ Category Dropdown
            _buildLabel("Category"),
            _buildCategoryDropdown(),

            if (isOtherCategory) ...[
              const SizedBox(height: 12),
              _buildLabel("Specify Category"),

              TextField(
                controller: otherCategoryController,
                decoration: _inputDecoration().copyWith(
                  hintText: "Enter category name",
                ),
              ),
            ],

            const SizedBox(height: 20),


            // ✅ Priority Selection
            _buildLabel("Priority Level"),
            Row(
              children: ['Low', 'Medium', 'High', 'Urgent']
                  .map(
                    (p) => Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      label: Text(
                        p,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: selectedPriority == p
                              ? Colors.white
                              : const Color.fromARGB(255, 82, 133, 124),
                        ),
                      ),
                      selected: selectedPriority == p,
                      selectedColor: primaryGreen,
                      backgroundColor: Colors.white,
                      side: BorderSide(
                        color: selectedPriority == p
                            ? primaryGreen
                            : primaryGreen.withValues(alpha: 0.45),
                      ),
                      onSelected: (_) =>
                          setState(() => selectedPriority = p),
                    ),
                  ),
                ),
              )
                  .toList(),
            ),
            const SizedBox(height: 20),

            // ✅ Description
            _buildLabel("Description"),
            TextField(
              controller: descriptionController,
              maxLines: 4,
              decoration: _inputDecoration().copyWith(
                hintText: "Explain the issue in detail...",
              ),
            ),
            const SizedBox(height: 16),

            // ✅ Add Photos Section (NEW)
            _buildLabel("Add Photos (optional)"),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: BorderSide(color: primaryGreen.withValues(alpha:0.55)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      backgroundColor: Colors.white,
                    ),
                    onPressed: () => _pickImage(fromCamera: false),
                    icon: Icon(
                      Icons.photo_library_outlined,
                      color: primaryGreen,
                    ),
                    label: Text(
                      "Gallery",
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: primaryGreen,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: BorderSide(color: primaryGreen.withValues(alpha: 0.55)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      backgroundColor: Colors.white,
                    ),
                    onPressed: () => _pickImage(fromCamera: true),
                    icon: Icon(Icons.camera_alt_outlined, color: primaryGreen),
                    label: Text(
                      "Camera",
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: primaryGreen,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 14),

            // ✅ Preview Selected Photos
            if (pickedImages.isNotEmpty) _buildPickedImagesGrid(),

            const SizedBox(height: 20),

            // ✅ Public Toggle
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text(
                "Make this issue public",
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: Color.fromARGB(255, 4, 45, 79),
                ),
              ),
              subtitle: const Text(
                "Other students can see and upvote this.",
                style: TextStyle(color: Colors.black54),
              ),
              value: isPublic,
              activeThumbColor: const Color.fromARGB(255, 6, 24, 66),
              activeTrackColor: primaryGreen.withValues(alpha: 0.35),
              inactiveThumbColor: Colors.grey.shade400,
              inactiveTrackColor: Colors.grey.shade300,
              onChanged: (val) => setState(() => isPublic = val),
            ),

            const SizedBox(height: 30),

            // ✅ Submit Button
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryGreen,
                  foregroundColor: Colors.white,
                  elevation: 4,
                  shadowColor: primaryGreen.withValues(alpha: 0.25),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onPressed: isSubmitting ? null : _submitIssue,
                child: isSubmitting
                    ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                )
                    : const Text(
                  "Submit Report",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ✅ Pick Image (camera/gallery)
  Future<void> _pickImage({required bool fromCamera}) async {
    if (pickedImages.length >= 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("You can upload up to 4 photos only.")),
      );
      return;
    }

    final XFile? image = await _picker.pickImage(
      source: fromCamera ? ImageSource.camera : ImageSource.gallery,
      imageQuality: 70,
    );

    if (image != null) {
      setState(() => pickedImages.add(image));
    }
  }

  // ✅ Preview Grid of selected photos with remove button
  Widget _buildPickedImagesGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: pickedImages.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
      ),
      itemBuilder: (context, index) {
        final img = pickedImages[index];

        return Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: kIsWeb
                  ? Image.network(
                img.path, // ✅ Works in web
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
              )
                  : Image.file(
                File(img.path), // ✅ Works in mobile/desktop
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
              ),
            ),

            // ❌ Remove button
            Positioned(
              top: 4,
              right: 4,
              child: InkWell(
                onTap: () => setState(() => pickedImages.removeAt(index)),
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.55),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close, size: 14, color: Colors.white),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ✅ Category Dropdown
  Widget _buildCategoryDropdown() {
    final categories = [
      {"name": "Plumbing", "icon": Icons.plumbing},
      {"name": "Electrical", "icon": Icons.electrical_services},
      {"name": "WiFi", "icon": Icons.wifi},
      {"name": "Cleanliness", "icon": Icons.cleaning_services},
      {"name": "Furniture", "icon": Icons.chair},
      {"name": "Others", "icon": Icons.more_horiz},
    ];

    return SizedBox(
      height: 55,
      child: DropdownButtonFormField<String>(
        initialValue: selectedCategory,
        isExpanded: true,
        icon: Icon(Icons.keyboard_arrow_down_rounded, color: primaryGreen),
        dropdownColor: Colors.white,
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 12,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(
              color: Color.fromARGB(255, 35, 130, 116),
              width: 1.2,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(
              color: Color.fromARGB(255, 35, 130, 116),
              width: 1.2,
            ),
          ),
        ),
        selectedItemBuilder: (context) {
          return categories.map((c) {
            return Row(
              children: [
                Icon(c["icon"] as IconData, color: primaryGreen, size: 20),
                const SizedBox(width: 12),
                Text(
                  c["name"] as String,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
              ],
            );
          }).toList();
        },
        items: categories.map((c) {
          return DropdownMenuItem<String>(
            value: c["name"] as String,
            child: Row(
              children: [
                Icon(c["icon"] as IconData, color: primaryGreen, size: 20),
                const SizedBox(width: 12),
                Text(
                  c["name"] as String,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
        onChanged: (val) {
          setState(() {
            selectedCategory = val!;
            isOtherCategory = val == "Others";
            if (!isOtherCategory) otherCategoryController.clear();
          });
        },

      ),
    );
  }

  // ✅ Label
  Widget _buildLabel(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      text,
      style: const TextStyle(
        fontWeight: FontWeight.w700,
        fontSize: 14,
        color: Color.fromARGB(255, 4, 45, 79),
      ),
    ),
  );

  // ✅ Input Decoration
  InputDecoration _inputDecoration() => InputDecoration(
    filled: true,
    fillColor: Colors.white,
    hintStyle: const TextStyle(color: Colors.black45),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: borderGreen, width: 1.2),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: primaryGreen, width: 2),
    ),
  );
  Duration _getResponseTime(String priority) {
    switch (priority) {
      case 'Urgent': // your UI uses "Urgent"
        return const Duration(hours: 1);
      case 'High':
        return const Duration(hours: 6);
      case 'Medium':
        return const Duration(hours: 24);
      case 'Low':
        return const Duration(hours: 48);
      default:
        return const Duration(hours: 24);
    }
  }

  // ✅ Submit Issue to Firebase
  Future<void> _submitIssue() async {
    // Validate description
    if (isOtherCategory && otherCategoryController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please provide a description of the issue")),
      );
      return;
    }

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please sign in to report an issue")),
      );
      return;
    }

    setState(() => isSubmitting = true);

    try {
      // Get user details from Firestore
      final now = DateTime.now();
      final deadline = now.add(_getResponseTime(selectedPriority));
      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      final userData = userDoc.data();

      final userName = userData?['name'] ?? 'Unknown';
      final userHostel = userData?['hostel'] ??
          (userData?['block'] != null && userData?['room'] != null
              ? "${userData?['block']}/${userData?['room']}"
              : 'Unknown');

      // Upload images to Firebase Storage and get URLs
      List<String> imageUrls = [];
      if (pickedImages.isNotEmpty) {
        for (int i = 0; i < pickedImages.length; i++) {
          final imageFile = File(pickedImages[i].path);
          final fileName = 'issues/${user.uid}/${DateTime.now().millisecondsSinceEpoch}_$i.jpg';

          try {
            final ref = _storage.ref().child(fileName);
            await ref.putFile(imageFile);
            final url = await ref.getDownloadURL();
            imageUrls.add(url);
          } catch (e) {
            // If image upload fails, continue with other images
            print('Error uploading image $i: $e');
          }
        }
      }

      // Create issue document in Firestore
      final issueData = {
        'userId': user.uid,
        'userName': userName,
        'hostel': userHostel,
        'title': descriptionController.text.trim().split('\n').first, // First line as title
        'description': descriptionController.text.trim(),
        'category': isOtherCategory
            ? otherCategoryController.text.trim()
            : selectedCategory,

        'priority': selectedPriority,
        'status': 'Reported',
        'isPublic': isPublic,
        'imageUrls': imageUrls,
        'createdAt': Timestamp.fromDate(now),
        'deadlineAt': Timestamp.fromDate(deadline),
        'isOverdue': false,
        'escalationLevel': 0,
        'updatedAt': FieldValue.serverTimestamp(),
        'upvotes': 0,
        'upvotedBy': <String>[],
        'remarks': <Map<String, dynamic>>[], // Initialize empty remarks array


      };

      await _firestore.collection('issues').add(issueData);
      if (!mounted) return;

      // Navigate directly to the detail screen showing this issue
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => IssueDetailScreen(
            title: issueData['title'] as String,
            description: issueData['description'] as String,
            category: issueData['category'] as String,
            priority: issueData['priority'] as String,
            imageUrls: imageUrls,
          ),
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Error reporting issue: ${e.toString()}"),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => isSubmitting = false);
      }
    }
  }

  @override
  void dispose() {
    descriptionController.dispose();
    otherCategoryController.dispose();
    super.dispose();
  }
}

