import 'package:flutter/material.dart';
import '../../widgets/custom_nav_bar.dart';
// Import the widget
// Import your other screens here

class StudentMainWrapper extends StatefulWidget {
  const StudentMainWrapper({super.key});

  @override
  State<StudentMainWrapper> createState() => _StudentMainWrapperState();
}

class _StudentMainWrapperState extends State<StudentMainWrapper> with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  late AnimationController _glowController;

  final List<Widget> _pages = [
    const Center(child: Text("Dashboard")), // Replace with DashboardScreen()
    const Center(child: Text("Mess Menu")), // Replace with MessMenuScreen()
    const Center(child: Text("Leave Request")), // Replace with LeaveRequestScreen()
    const Center(child: Text("Profile")), // Replace with ProfileScreen()
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _currentIndex, children: _pages),
      bottomNavigationBar: CustomNavBar(
        selectedIndex: _currentIndex,
        glowController: _glowController,
        onItemSelected: (index) => setState(() => _currentIndex = index),
      ),
    );
  }
}