import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminAnnouncementScreen extends StatefulWidget {
  const AdminAnnouncementScreen({super.key});

  @override
  State<AdminAnnouncementScreen> createState() =>
      _AdminAnnouncementScreenState();
}

class _AdminAnnouncementScreenState extends State<AdminAnnouncementScreen> {
  // 🎨 Palette
  static const Color primary = Color(0xFF22577A);
  static const Color secondary = Color(0xFF38A3A5);
  static const Color success = Color(0xFF57CC99);
  static const Color highlight = Color(0xFF80ED99);
  static const Color background = Color(0xFFC7F9CC);
  final TextEditingController _titleCtrl = TextEditingController();
  final TextEditingController _messageCtrl = TextEditingController();
  String selectedAudience = "All Hostel";
  String selectedPriority = "Normal";


  final Stream<QuerySnapshot> announcementStream =
  FirebaseFirestore.instance
      .collection('announcements')
      .orderBy('createdAt', descending: true)
      .snapshots();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: background,
        foregroundColor: primary,
        title: const Text(
          "Announcements",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: announcementStream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No announcements"));
          }

          final announcements = snapshot.data!.docs;

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: announcements.length,
            itemBuilder: (_, index) {
              final doc = announcements[index];
              final data = doc.data() as Map<String, dynamic>;
              return _announcementCard(data, doc.id);

            },
          );
        },
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: secondary,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: _showAddSheet,
      ),
    );
  }

  /// 📢 ANNOUNCEMENT CARD
  Widget _announcementCard(Map<String, dynamic> data, String docId) {
    final bool urgent = data['priority'] == 'Urgent';

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: primary.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: secondary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    urgent ? Icons.warning_rounded : Icons.campaign_rounded,
                    color: secondary,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        data['title'],
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: primary,
                        ),
                      ),
                      Text(
                        data['createdAt'] != null
                            ? (data['createdAt'] as Timestamp)
                            .toDate()
                            .toString()
                            .substring(0, 16)
                            : '',
                        style: TextStyle(
                          fontSize: 12,
                          color: primary.withOpacity(0.6),
                        ),
                      ),

                    ],
                  ),
                ),
                _priorityChip(data['priority']),
              ],
            ),
          ),

          // Message
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              data['message'],
              style: TextStyle(
                fontSize: 14,
                height: 1.5,
                color: primary.withOpacity(0.85),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // Footer
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: highlight.withOpacity(0.35),
              borderRadius:
              const BorderRadius.vertical(bottom: Radius.circular(18)),
            ),
            child: Row(
              children: [
                const Icon(Icons.groups, size: 16, color: primary),
                const SizedBox(width: 6),
                Text(
                  data['audience'],
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: primary,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _showEditSheet(data, docId),
                  child: Icon(Icons.edit, size: 18, color: secondary),
                ),

                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () async {
                    await FirebaseFirestore.instance
                        .collection('announcements')
                        .doc(docId)
                        .delete();
                  },
                  child: const Icon(Icons.delete, size: 18, color: Colors.redAccent),
                ),

              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _priorityChip(String priority) {
    Color color;

    switch (priority) {
      case 'Urgent':
        color = Colors.red;
        break;
      case 'Important':
        color = Colors.orange;
        break;
      default:
        color = success;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        priority,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
    );
  }


  /// ➕ ADD SHEET
  void _showAddSheet() {
    selectedAudience = "All Hostel";
    selectedPriority = "Normal";
    _titleCtrl.clear();
    _messageCtrl.clear();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 5,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),
                  const Text(
                    "New Announcement",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: primary,
                    ),
                  ),

                  const SizedBox(height: 20),
                  _input("Title", controller: _titleCtrl),
                  const SizedBox(height: 12),
                  _input("Message", maxLines: 3, controller: _messageCtrl),

                  const SizedBox(height: 20),

                  /// AUDIENCE
                  const Text("Audience",
                      style: TextStyle(fontWeight: FontWeight.w600, color: primary)),
                  const SizedBox(height: 8),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: highlight.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: selectedAudience,
                        isExpanded: true,
                        items: const [
                          DropdownMenuItem(value: "All Hostel", child: Text("All Hostel")),
                          DropdownMenuItem(value: "Block A", child: Text("Block A")),
                          DropdownMenuItem(value: "Block B", child: Text("Block B")),
                          DropdownMenuItem(value: "Block C", child: Text("Block C")),
                        ],
                        onChanged: (val) {
                          setModalState(() => selectedAudience = val!);
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  /// PRIORITY
                  const Text("Priority",
                      style: TextStyle(fontWeight: FontWeight.w600, color: primary)),
                  const SizedBox(height: 10),

                  Row(
                    children: [
                      _priorityChipUI("Normal", success, setModalState),
                      const SizedBox(width: 8),
                      _priorityChipUI("Important", Colors.orange, setModalState),
                      const SizedBox(width: 8),
                      _priorityChipUI("Urgent", Colors.red, setModalState),
                    ],
                  ),

                  const SizedBox(height: 28),

                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: secondary,
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    onPressed: _publishAnnouncement,
                    child: const Text(
                      "Publish Announcement",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _priorityChipUI(String value, Color color, void Function(void Function()) setModalState) {
    final bool selected = selectedPriority == value;

    return ChoiceChip(
      label: Text(value),
      selected: selected,
      selectedColor: color.withOpacity(0.25),
      labelStyle: TextStyle(
        color: selected ? color : primary,
        fontWeight: FontWeight.w600,
      ),
      onSelected: (_) {
        setModalState(() => selectedPriority = value);
      },
    );
  }

  Future<void> _publishAnnouncement() async {
    if (_titleCtrl.text.trim().isEmpty ||
        _messageCtrl.text.trim().isEmpty) return;

    await FirebaseFirestore.instance.collection('announcements').add({
      'title': _titleCtrl.text.trim(),
      'message': _messageCtrl.text.trim(),
      'audience': selectedAudience,
      'priority': selectedPriority,
      'createdAt': FieldValue.serverTimestamp(),
    });

    _titleCtrl.clear();
    _messageCtrl.clear();
    selectedAudience = "All Hostel";
    selectedPriority = "Normal";

    Navigator.pop(context);
  }



  void _showEditSheet(Map<String, dynamic> data, String docId) {
    _titleCtrl.text = data['title'];
    _messageCtrl.text = data['message'];

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _input("Title", controller: _titleCtrl),
            const SizedBox(height: 12),
            _input("Message", maxLines: 3, controller: _messageCtrl),
            const SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: secondary,
                minimumSize: const Size(double.infinity, 48),
              ),
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('announcements')
                    .doc(docId)
                    .update({
                  'title': _titleCtrl.text.trim(),
                  'message': _messageCtrl.text.trim(),
                });

                _titleCtrl.clear();
                _messageCtrl.clear();
                Navigator.pop(context);
              },
              child: const Text("Update"),
            )
          ],
        ),
      ),
    );
  }


  Widget _input(String hint,
      {int maxLines = 1, TextEditingController? controller}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: highlight.withOpacity(0.25),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
