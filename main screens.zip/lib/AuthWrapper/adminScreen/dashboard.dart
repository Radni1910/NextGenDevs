import 'package:flutter/material.dart';
import 'package:dormtrack/AuthWrapper/adminScreen/lostfound.dart';
import 'package:dormtrack/AuthWrapper/adminScreen/issuemanage.dart';
import 'package:dormtrack/AuthWrapper/adminScreen/annoucement.dart';
import 'package:dormtrack/AuthWrapper/adminScreen/analytic.dart';
import 'package:dormtrack/AuthWrapper/adminScreen/assignment.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  static const Color primary = Color(0xFF22577A);
  static const Color secondary = Color(0xFF38A3A5);
  static const Color success = Color(0xFF57CC99);
  static const Color highlight = Color(0xFF80ED99);
  static const Color background = Color(0xFFC7F9CC);

  int _selectedIndex = 0;
  OverlayEntry? _notificationOverlay;

  // 🎨 Palette


  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final bool isDesktop = width >= 1100;
    final bool isTablet = width >= 650 && width < 1100;

    return Scaffold(
      backgroundColor: background.withOpacity(0.35),
      body: Row(
        children: [
          // 🧭 Sidebar
          if (isDesktop || isTablet)
            NavigationRail(
              extended: isDesktop,
              backgroundColor: Colors.white,
              selectedIndex: _selectedIndex,
              selectedIconTheme: const IconThemeData(color: primary),
              unselectedIconTheme: const IconThemeData(color: Colors.grey),
              onDestinationSelected: (index) {
                setState(() => _selectedIndex = index);
              },
              leading: Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: CircleAvatar(
                  backgroundColor: primary,
                  child: const Icon(Icons.admin_panel_settings,
                      color: Colors.white),
                ),
              ),
              destinations: const [
                NavigationRailDestination(
                    icon: Icon(Icons.dashboard_rounded),
                    label: Text('Dashboard')),
                NavigationRailDestination(
                    icon: Icon(Icons.bar_chart_rounded),
                    label: Text('Analytics')),
                NavigationRailDestination(
                    icon: Icon(Icons.settings_rounded),
                    label: Text('Settings')),
              ],
            ),

          // 📄 Main Content
          Expanded(
            child: CustomScrollView(
              slivers: [
                _buildAppBar(),
                SliverPadding(
                  padding: const EdgeInsets.all(24),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      _buildHeaderCard(),
                      const SizedBox(height: 28),
                      _sectionTitle("Overview"),
                      const SizedBox(height: 16),
                      _buildStatsRow(),
                      const SizedBox(height: 32),
                      _sectionTitle("Quick Actions"),
                      const SizedBox(height: 16),
                    ]),
                  ),
                ),
                _buildActionGrid(width),
                const SliverToBoxAdapter(child: SizedBox(height: 40)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // 🔝 AppBar
  Widget _buildAppBar() {
    return SliverAppBar(
      pinned: true,
      floating: true,
      backgroundColor: Colors.white,
      elevation: 0,
      title: const Text(
        "Admin Dashboard",
        style: TextStyle(fontWeight: FontWeight.bold, color: primary),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.notifications_none),
          color: primary,
          onPressed: _toggleNotificationCard,
        ),

        const SizedBox(width: 8),
        const CircleAvatar(
          radius: 16,
          backgroundColor:  Colors.teal,
          child: Icon(Icons.person, color: Colors.white, size: 18),
        ),
        const SizedBox(width: 16),
      ],
    );
  }

  void _toggleNotificationCard() {
    if (_notificationOverlay != null) {
      _notificationOverlay!.remove();
      _notificationOverlay = null;
      return;
    }

    _notificationOverlay = OverlayEntry(
      builder: (_) => GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () {
          _notificationOverlay?.remove();
          _notificationOverlay = null;
        },
        child: Stack(
          children: [
            Positioned(
              top: kToolbarHeight + 12,
              right: 24,
              child: _notificationCard(),
            ),
          ],
        ),
      ),
    );

    Overlay.of(context).insert(_notificationOverlay!);
  }


  // 👋 Header Card
  Widget _buildHeaderCard() {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance
          .collection('management')
          .doc(uid)
          .snapshots(),
      builder: (context, snapshot) {
        String adminName = "Admin";
        String role = "";

        if (snapshot.hasData && snapshot.data!.exists) {
          final data = snapshot.data!.data() as Map<String, dynamic>;
          adminName = data['name'] ?? "Admin";
          role = data['role'] ?? "";
        }

        return Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [primary, secondary],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: primary.withOpacity(0.25),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Welcome, $adminName 👋",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                role.isNotEmpty
                    ? "Role: $role"
                    : "Monitor hostel operations and manage activities",
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // 📊 Stats
  Widget _buildStatsRow() {
    return Row(
      children: [
        // 🛠 Open Issues
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('issues')
                .where('status', isEqualTo: 'Open') // ✅ FIXED
                .snapshots(),
            builder: (context, snapshot) {
              final count =
              snapshot.hasData ? snapshot.data!.docs.length : 0;
              return _statCard("Open Issues", count.toString(), primary);
            },
          ),
        ),

        // ✅ Resolved Issues
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('issues')
                .where('status', isEqualTo: 'Resolved') // ✅ FIXED
                .snapshots(),
            builder: (context, snapshot) {
              final count =
              snapshot.hasData ? snapshot.data!.docs.length : 0;
              return _statCard("Resolved", count.toString(), success);
            },
          ),
        ),

        // 🔍 Lost Items
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('lost_found')
                .snapshots(),
            builder: (context, snapshot) {
              final count =
              snapshot.hasData ? snapshot.data!.docs.length : 0;
              return _statCard("Lost Items", count.toString(), secondary);
            },
          ),
        ),

        // 👥 Users
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('students')
                .snapshots(),
            builder: (context, snapshot) {
              final count =
              snapshot.hasData ? snapshot.data!.docs.length : 0;
              return _statCard("Users", count.toString(), primary);
            },
          ),
        ),
      ],
    );
  }


  Widget _statStream({
    required String title,
    required Color color,
    required Stream<QuerySnapshot> stream,
  }) {
    return StreamBuilder<QuerySnapshot>(
      stream: stream,
      builder: (context, snapshot) {
        final count = snapshot.hasData ? snapshot.data!.docs.length : 0;
        return _statCard(title, count.toString(), color);
      },
    );
  }


  Widget _statCard(String title, String value, Color color) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            title,
            style: const TextStyle(
              fontSize: 13,
              color: Colors.black54,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }


  // 🧩 Action Grid
  Widget _buildActionGrid(double width) {
    int crossAxisCount = width >= 1200
        ? 4
        : width >= 800
        ? 3
        : 2;

    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      sliver: SliverGrid(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
          childAspectRatio: 1.15,
        ),
        delegate: SliverChildListDelegate([
          _actionCard(
            icon: Icons.assignment_rounded,
            title: "Manage Issues",
            color: primary,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const IssueManageScreen()),
            ),
          ),
          _actionCard(
            icon: Icons.analytics_rounded,
            title: "Analytics",
            color: Colors.teal,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) =>  AdminAnalyticsScreen()),
            ),
          ),
          _actionCard(
            icon: Icons.campaign_rounded,
            title: "Announcements",
            color: success,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => const AdminAnnouncementScreen()),
            ),
          ),
          _actionCard(
            icon: Icons.find_in_page_rounded,
            title: "Lost & Found",
            color: primary,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AdminLostFoundScreen()),
            ),
          ),
          _actionCard(
            icon: Icons.assignment_outlined,
            title: "Assignments",
            color: secondary,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AssignmentScreen(),),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _actionCard({
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.15),
              ),
              child: Icon(icon, size: 30, color: color),
            ),
            const SizedBox(height: 14),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: primary),
    );
  }
}

Widget _notificationCard() {
  return Material(
    elevation: 10,
    borderRadius: BorderRadius.circular(18),
    child: Container(
      width: 320,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Notifications",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),

          /// 🔔 ISSUE NOTIFICATIONS
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('issues')
                .orderBy('createdAt', descending: true)
                .limit(3)
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const SizedBox();

              return Column(
                children: snapshot.data!.docs.map((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  final status = data['status'] ?? '';

                  return _notificationItem(
                    Icons.assignment_rounded,
                    status == 'Resolved'
                        ? "Issue resolved"
                        : "New issue reported",
                    data['category'] ?? '',
                  );
                }).toList(),
              );
            },
          ),

          const SizedBox(height: 8),

          /// 🔍 LOST & FOUND NOTIFICATIONS
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('lost_found')
                .orderBy('createdAt', descending: true)
                .limit(2)
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const SizedBox();

              return Column(
                children: snapshot.data!.docs.map((doc) {
                  final data = doc.data() as Map<String, dynamic>;

                  return _notificationItem(
                    Icons.find_in_page_rounded,
                    "Lost item posted",
                    data['itemName'] ?? 'New item',
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    ),
  );
}

Widget _notificationItem(
    IconData icon, String title, String subtitle) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      children: [
        Icon(icon, size: 18, color: Colors.teal,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600),
              ),
              if (subtitle.isNotEmpty)
                Text(
                  subtitle,
                  style: const TextStyle(
                      fontSize: 11, color: Colors.grey),
                ),
            ],
          ),
        ),
      ],
    ),
  );
}

