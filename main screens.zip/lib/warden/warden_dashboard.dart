import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class WardenDashboard extends StatelessWidget {
  const WardenDashboard({super.key});

  static const Color primary = Color(0xFF22577A);
  static const Color background = Color(0xFFF1FAEE);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,

      appBar: AppBar(
        title: const Text(
          "Issues Assigned to Warden",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        foregroundColor: primary,
        elevation: 0,
      ),

      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('issues')
            .where('assignedTo', isEqualTo: 'Warden')
            .orderBy('createdAt', descending: true)
            .snapshots(),

        builder: (context, snapshot) {
          // ⏳ Loading
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          // ❌ Error
          if (snapshot.hasError) {
            return const Center(
              child: Text(
                "Failed to load issues",
                style: TextStyle(color: Colors.red),
              ),
            );
          }

          final issues = snapshot.data?.docs ?? [];

          // 📭 No assigned issues
          if (issues.isEmpty) {
            return const Center(
              child: Text(
                "No issues assigned to you yet",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            );
          }

          // ✅ Assigned issues list
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: issues.length,
            itemBuilder: (context, index) {
              return _issueCard(issues[index]);
            },
          );
        },
      ),
    );
  }

  // ================= ISSUE CARD =================
  Widget _issueCard(QueryDocumentSnapshot doc) {
    final issue = doc.data() as Map<String, dynamic>;

    final title = issue['title'] ?? 'Issue';
    final category = issue['category'] ?? 'General';
    final priority = (issue['priority'] ?? 'Medium').toString();
    final status = issue['status'] ?? 'In Progress';

    Color priorityColor;
    switch (priority.toLowerCase()) {
      case 'urgent':
        priorityColor = Colors.red;
        break;
      case 'high':
        priorityColor = Colors.deepOrange;
        break;
      case 'low':
        priorityColor = Colors.green;
        break;
      default:
        priorityColor = Colors.orange;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title + Priority
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Chip(
                  label: Text(priority),
                  backgroundColor: priorityColor.withValues(alpha: .15),
                ),
              ],
            ),

            const SizedBox(height: 6),

            Text(
              "Category: $category",
              style: const TextStyle(color: Colors.black54),
            ),

            const SizedBox(height: 6),

            Text(
              "Status: $status",
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Colors.blueGrey,
              ),
            ),

            const SizedBox(height: 14),

            // Resolve Button
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: () async {
                  await FirebaseFirestore.instance
                      .collection('issues')
                      .doc(doc.id)
                      .update({
                    'status': 'Resolved',
                    'resolvedAt': FieldValue.serverTimestamp(),
                  });
                },
                child: const Text("Mark Resolved"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
