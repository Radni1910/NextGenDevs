import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AssignmentScreen extends StatefulWidget {
  const AssignmentScreen({super.key});

  @override
  State<AssignmentScreen> createState() => _AssignmentScreenState();
}

class _AssignmentScreenState extends State<AssignmentScreen> {
  String selectedFilter = 'All';

  static const Color bg = Color(0xFFF8FAFC);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        title: const Text('Issue Assignment'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),

      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('issues')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(child: Text('Failed to load issues'));
          }

          final allIssues = snapshot.data?.docs ?? [];

          final filteredIssues = allIssues.where((doc) {
            final data = doc.data() as Map<String, dynamic>;
            final status = data['status'] ?? 'Unassigned';
            return selectedFilter == 'All' || status == selectedFilter;
          }).toList();

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _buildSummary(allIssues),
                const SizedBox(height: 16),
                _buildFilters(),
                const SizedBox(height: 16),

                Expanded(
                  child: ListView.builder(
                    itemCount: filteredIssues.length,
                    itemBuilder: (context, index) {
                      return _buildAssignmentCard(filteredIssues[index]);
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ================= SUMMARY =================
  Widget _buildSummary(List<QueryDocumentSnapshot> issues) {
    int unassigned = issues
        .where((i) =>
    ((i.data() as Map)['assignedTo'] == null))
        .length;

    int assigned = issues
        .where((i) =>
    ((i.data() as Map)['assignedTo'] != null))
        .length;

    int completed = issues
        .where((i) =>
    ((i.data() as Map)['status'] ?? '') == 'Resolved')
        .length;

    return Row(
      children: [
        _summaryTile('Total', issues.length, Colors.blue),
        _summaryTile('Unassigned', unassigned, Colors.red),
        _summaryTile('Assigned', assigned, Colors.orange),
        _summaryTile('Done', completed, Colors.green),
      ],
    );
  }

  Widget _summaryTile(String title, int count, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(
              count.toString(),
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: color,
              ),
            ),
            Text(title, style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }

  // ================= FILTERS =================
  Widget _buildFilters() {
    final filters = [];

    return Row(
      children: filters.map((filter) {
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(
            label: Text(filter),
            selected: selectedFilter == filter,
            onSelected: (_) {
              setState(() => selectedFilter = filter);
            },
          ),
        );
      }).toList(),
    );
  }

  // ================= ISSUE CARD =================
  Widget _buildAssignmentCard(QueryDocumentSnapshot doc) {
    final issue = doc.data() as Map<String, dynamic>;

    final title = issue['title'] ?? 'Issue';
    final category = issue['category'] ?? 'General';
    final location = issue['location'] ?? '';
    final assignedTo = issue['assignedTo'];

    final String priority =
    (issue['priority'] ?? 'Medium').toString();

    Color priorityColor;
    switch (priority.toLowerCase()) {
      case 'urgent':
        priorityColor = Colors.red;
        break;
      case 'high':
        priorityColor = Colors.deepOrange;
        break;
      case 'medium':
        priorityColor = Colors.orange;
        break;
      case 'low':
        priorityColor = Colors.green;
        break;
      default:
        priorityColor = Colors.grey;
    }


    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                Chip(
                  label: Text(priority),
                  backgroundColor: priorityColor.withOpacity(0.15),
                )

              ],
            ),

            const SizedBox(height: 6),
            if (location.isNotEmpty)
              Text(location, style: const TextStyle(color: Colors.grey)),

            const SizedBox(height: 6),
            Text('Category: $category'),

            const SizedBox(height: 6),
            Text(
              assignedTo == null
                  ? 'Not Assigned'
                  : 'Assigned to: $assignedTo',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: assignedTo == null
                    ? Colors.red
                    : Colors.green,
              ),
            ),

            const SizedBox(height: 12),

            if (assignedTo == null)
              Align(
                alignment: Alignment.centerRight,
                child: ElevatedButton(
                  onPressed: () => _assignToWarden(doc),
                  child: const Text('Assign'),
                ),
              ),

          ],
        ),
      ),
    );
  }

  // ================= ASSIGN TO WARDEN =================
  void _assignToWarden(QueryDocumentSnapshot doc) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Assign Issue',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              const Text(
                'This issue will be assigned to the Warden.',
                style: TextStyle(color: Colors.black54),
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    await FirebaseFirestore.instance
                        .collection('issues')
                        .doc(doc.id)
                        .update({
                      'assignedTo': 'Warden',
                      'status': 'In Progress',
                      'assignedAt': FieldValue.serverTimestamp(),
                    });

                    Navigator.pop(context);
                  },
                  child: const Text('Assign to Warden'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
