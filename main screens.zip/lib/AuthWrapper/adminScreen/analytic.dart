import 'package:flutter/material.dart';
import 'package:dormtrack/services/analytics_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';

class AdminAnalyticsScreen extends StatelessWidget {

  AdminAnalyticsScreen({super.key});
  final AnalyticsService analytics = AnalyticsService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FF),
      appBar: AppBar(
        title: const Text('Analytics'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _overviewSection(),
            const SizedBox(height: 24),
            _sectionTitle("Issue Status"),
            const SizedBox(height: 12),
            _statusProgress(),
            const SizedBox(height: 24),
            _sectionTitle("Category Breakdown"),
            const SizedBox(height: 12),
            _categoryCards(),
            const SizedBox(height: 24),
            _sectionTitle("Recent Insights"),
            const SizedBox(height: 12),
            _recentInsights(),
          ],
        ),
      ),
    );
  }

  // 🔹 Overview Cards
  Widget _overviewSection() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      children: [
        StreamBuilder<int>(
          stream: analytics.totalIssues(),
          builder: (context, snapshot) {
            return _overviewCard(
              "Total Issues",
              (snapshot.data ?? 0).toString(),
              Icons.assignment,
              Colors.blue,
            );
          },
        ),

        StreamBuilder<int>(
          stream: analytics.resolvedIssues(),
          builder: (context, snapshot) {
            return _overviewCard(
              "Resolved",
              (snapshot.data ?? 0).toString(),
              Icons.check_circle,
              Colors.green,
            );
          },
        ),

        StreamBuilder<int>(
          stream: analytics.openIssues(),
          builder: (context, snapshot) {
            return _overviewCard(
              "Pending",
              (snapshot.data ?? 0).toString(),
              Icons.pending,
              Colors.orange,
            );
          },
        ),

        StreamBuilder<int>(
          stream: FirebaseFirestore.instance
              .collection('lostFound')
              .snapshots()
              .map((s) => s.size),
          builder: (context, snapshot) {
            return _overviewCard(
              "Lost & Found",
              (snapshot.data ?? 0).toString(),
              Icons.find_in_page,
              Colors.purple,
            );
          },
        ),

      ],
    );
  }

  Widget _overviewCard(
      String title, String count, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            backgroundColor: color.withOpacity(0.15),
            child: Icon(icon, color: color),
          ),
          const SizedBox(height: 14),
          Text(
            count,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }

  // 🔹 Status Progress
  Widget _statusProgress() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('issues').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;
        final total = docs.length;

        if (total == 0) {
          return const Text("No issues yet");
        }

        final resolved =
            docs.where((d) => d.data().toString().contains('status') &&
                d['status'] == 'Resolved').length;

        final open =
            docs.where((d) => d.data().toString().contains('status') &&
                d['status'] == 'Open').length;


        return Container(
          padding: const EdgeInsets.all(16),
          decoration: _cardDecoration(),
          child: Column(
            children: [
              _progressTile(
                "Resolved",
                resolved / total,
                Colors.green,
              ),
              _progressTile(
                "Open",
                open / total,
                Colors.red,
              ),
            ],
          ),
        );
      },
    );
  }


  Widget _progressTile(String title, double value, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style:
              const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: value,
              minHeight: 10,
              backgroundColor: color.withOpacity(0.15),
              valueColor: AlwaysStoppedAnimation(color),
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 Category Cards
  Widget _categoryCards() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('issues').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        Map<String, int> categoryCount = {};

        for (var doc in snapshot.data!.docs) {
          final data = doc.data() as Map<String, dynamic>;
          final category = data['category'] ?? 'Others';

          categoryCount[category] =
              (categoryCount[category] ?? 0) + 1;
        }

        if (categoryCount.isEmpty) {
          return const Text("No category data available");
        }

        return Container(
          padding: const EdgeInsets.all(16),
          decoration: _cardDecoration(),
          child: _categoryPieChart(categoryCount),
        );
      },
    );
  }



  // 🔹 Recent Insights
  Widget _recentInsights() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('issues')
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return _insightTile("No issues reported yet");
        }

        Map<String, int> categoryCount = {};
        Map<String, int> hostelCount = {};
        int open = 0;
        int resolved = 0;

        for (var doc in docs) {
          final data = doc.data() as Map<String, dynamic>;

          final hostel = data['userHostel'] ?? 'Unknown';
          final status = data['status'] ?? 'Open';


          hostelCount[hostel] =
              (hostelCount[hostel] ?? 0) + 1;

          if (status == 'Open') open++;
          if (status == 'Resolved') resolved++;

        }

        String topCategory = categoryCount.isNotEmpty
            ? categoryCount.entries
            .reduce((a, b) => a.value > b.value ? a : b)
            .key
            : "N/A";

        String topHostel = hostelCount.isNotEmpty
            ? hostelCount.entries
            .reduce((a, b) => a.value > b.value ? a : b)
            .key
            : "N/A";


        return Container(
          padding: const EdgeInsets.all(16),
          decoration: _cardDecoration(),
          child: Column(
            children: [
              _insightTile("Highest issues from: $topHostel"),
              _insightTile("Open: $open | Resolved: $resolved"),
            ],
          ),
        );
      },
    );
  }

}
Widget _sectionTitle(String title) {
  return Text(
    title,
    style: const TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.w700,
    ),
  );
}

BoxDecoration _cardDecoration() {
  return BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(20),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.05),
        blurRadius: 12,
        offset: const Offset(0, 6),
      ),
    ],
  );
}

Widget _insightTile(String text) {
  return ListTile(
    leading: const Icon(Icons.insights, color: Colors.indigo),
    title: Text(text),
  );
}

Widget _categoryPieChart(Map<String, int> categoryCount) {
  final total = categoryCount.values.fold(0, (a, b) => a + b);

  final colors = [
    const Color(0xFF4F46E5), // Indigo
    const Color(0xFF22C55E), // Green
    const Color(0xFFF97316), // Orange
    const Color(0xFFEC4899), // Pink
    const Color(0xFF14B8A6), // Teal
    const Color(0xFF8B5CF6), // Purple
  ];

  int index = 0;

  return Container(
    padding: const EdgeInsets.all(20),
    decoration: _cardDecoration(),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 🟣 PIE CHART
        SizedBox(
          height: 260,
          child: PieChart(
            PieChartData(
              centerSpaceRadius: 65,
              sectionsSpace: 4,
              startDegreeOffset: -90,
              centerSpaceColor: Colors.white,
              sections: categoryCount.entries.map((entry) {
                final percent = (entry.value / total) * 100;
                final color = colors[index % colors.length];

                index++;

                return PieChartSectionData(
                  value: entry.value.toDouble(),
                  color: color,
                  radius: 80,
                  title:
                  "${entry.key}\n${percent.toStringAsFixed(1)}%",
                  titleStyle: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                );
              }).toList(),
            ),
          ),
        ),

        const SizedBox(height: 24),

        // 🟢 LEGEND
        Wrap(
          spacing: 12,
          runSpacing: 10,
          children: categoryCount.entries.map((entry) {
            final color = colors[
            categoryCount.keys.toList().indexOf(entry.key) %
                colors.length];

            return Container(
              padding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "${entry.key} (${entry.value})",
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    ),
  );
}
